// Author: huythedev
// Problem Link: 
#include <bits/stdc++.h>
using namespace std;

#define NAME "GIFT"
#define ln "\n"
#define sz size()

typedef long long ll;
typedef long double ld;

void fastIO() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
}

void fileIO() {
    if (ifstream(NAME ".INP")) {
        freopen(NAME ".INP", "r", stdin);
        freopen(NAME ".OUT", "w", stdout);
    }
}

void time() {
    cerr << ln << "Time elapsed: " << 1.0 * clock() / CLOCKS_PER_SEC << "s." 
         << ln;
}

struct Gift {
    ll p, t;
};

bool compareGifts(const Gift& a, const Gift& b) {
    return a.p < b.p;
}

void solve() {
    int K, M, N;
    cin >> K >> M >> N;

    vector<Gift> gifts(K);
    for (int i = 0; i < K; ++i) {
        cin >> gifts[i].p >> gifts[i].t;
    }

    vector<ll> bFlags(M);
    for (int i = 0; i < M; ++i) {
        cin >> bFlags[i];
    }

    sort(gifts.begin(), gifts.end(), compareGifts);
    sort(bFlags.begin(), bFlags.end());

    vector<ll> vec;
    int idx = 0;

    for (int i = 0; i <= M; ++i) {
        ll start_pos = (i == 0) ? -1 : bFlags[i - 1];
        ll end_pos = (i == M) ? 2e9 + 7 : bFlags[i];

        vector<Gift> segment_gifts;
        while (idx < K && gifts[idx].p < end_pos) {
            if (gifts[idx].p > start_pos) {
                segment_gifts.push_back(gifts[idx]);
            }
            idx++;
        }

        if (segment_gifts.empty()) {
            continue;
        }

        ll segment_sum = 0;
        for (const auto& g : segment_gifts) {
            segment_sum += g.t;
        }

        if (i == 0 || i == M) {
            if (segment_sum > 0) {
                vec.push_back(segment_sum);
            }
        } 
        else {
            ll max_one_flag = 0;
            ll current_sum = 0;
            int l = 0;
            ll max_dist = end_pos - start_pos;

            for (int r = 0; r < segment_gifts.size(); ++r) {
                current_sum += segment_gifts[r].t;
                while (segment_gifts[r].p - segment_gifts[l].p > max_dist) {
                    current_sum -= segment_gifts[l].t;
                    l++;
                }
                max_one_flag = max(max_one_flag, current_sum);
            }

            if (max_one_flag > 0) {
                vec.push_back(max_one_flag);
            }
            if (segment_sum - max_one_flag > 0) {
                vec.push_back(segment_sum - max_one_flag);
            }
        }
    }
    
    sort(vec.rbegin(), vec.rend());

    ll ans = 0;
    for (int i = 0; i < N && i < vec.size(); ++i) {
        ans += vec[i];
    }

    cout << ans << endl;
}

signed main() {
    fastIO();
    fileIO();

    int t = 1;
    // cin >> t;
    while (t--) {
        solve();
    }

    time();
    return 0;
}