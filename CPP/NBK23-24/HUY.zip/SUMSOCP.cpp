#include <bits/stdc++.h>
using namespace std;

#define NAME "SUMSOCP"
#define ln '\n'

typedef long long ll;
typedef long double ld;

void docfile() {
    if(ifstream(NAME".inp")) {
        freopen(NAME".inp", "r", stdin);
        freopen(NAME".out", "w", stdout);
    }
}

bool isCP(int n) {
    return (int)sqrt(n) * (int)sqrt(n) == n;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL); cout.tie(NULL);
    docfile();

    int N; cin >> N;
    vector<int> a(N);
    int maxnum = 0;
    map<int, int> freq;
    for(int &x : a) {
        cin >> x;
        maxnum = max(maxnum, x);
        freq[x]++;
    }

    ll res = 0;
    for(int i = 0; i <= maxnum; ++i) {
        if(freq[i] == 0) {
            if(isCP(i))
                res += i;
        }
    }

    cout << res << ln;
    
    return 0;
}